﻿using Cosmos.System.FileSystem;
using Cosmos.System.FileSystem.VFS;
using System;
using FtpServer = CosmosFtpServer.FtpServer;

namespace CosmosTest
{
    internal class FTP2Server
    {
        private CosmosVFS fs;
        private FtpServer xServer;

        internal FTP2Server()
        {
            Console.WriteLine("Initializing VFS...");
            fs = new CosmosVFS();
            VFSManager.RegisterVFS(fs);

            try
            {
                if (!VFSManager.DirectoryExists("0:\\test_dir"))
                {
                    VFSManager.CreateDirectory("0:\\test_dir");
                    Console.WriteLine("Created '0:\\test_dir' directory.");
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("VFS Error: " + e.Message);
            }
        }

        internal void Initialize()
        {
            Console.WriteLine("FTP Server Initializing...");
            this.xServer = new FtpServer(fs, "0:\\");
            Console.WriteLine("FTP Initialized and ready.");
        }

        internal void Poll()
        {
            if (xServer != null)
            {
                xServer.Listen();
            }
        }
    }
}