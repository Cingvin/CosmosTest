﻿using CosmosTest.App.HttpServer;
using System;

namespace CosmosTest.App
{
    internal class Application
    {
        private FTP2Server ftpServer;

        public Application(Network network)
        {
            Console.WriteLine("Application: Constructor started.");

            Console.WriteLine("Application: Initializing FtpServer...");
            this.ftpServer = new FTP2Server();
            this.ftpServer.Initialize();

            Console.WriteLine("Application: FtpServer initialized and ready to poll.");
        }
        public void RunTasks()
        {
            if (this.ftpServer != null)
            {
                this.ftpServer.Poll();
            }
        }
    }
}