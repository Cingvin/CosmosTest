using Cosmos.System.Network.Config;
using System;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Linq;
using Sys = Cosmos.System;

namespace CosmosTest.App
{
	public class FtpServer
	{
		private TcpListener controlListener;
		private int controlPort = 21;
		private int passivePortCounter = 10000;
		private string rootPath = @"0:\";

		private const string FtpUsername = "testuser";
		private const string FtpPassword = "password";

		public FtpServer()
		{
			var address = new IPAddress(NetworkConfiguration.CurrentAddress.ToByteArray());

			Sys.FileSystem.CosmosVFS fs = new Sys.FileSystem.CosmosVFS();
			Sys.FileSystem.VFS.VFSManager.RegisterVFS(fs);
			Console.WriteLine("FTP Server: CosmosVFS registered.");

			try
			{
				if (!Directory.Exists(rootPath))
				{
					Console.WriteLine("FTP Server: Root directory not found: " + rootPath);
					Console.WriteLine("FTP Server: Please ensure '0:\\' is configured in Cosmos project Deployment settings.");
				}
				else
				{
					Console.WriteLine("FTP Server: Root directory exists: " + rootPath);
				}
			}
			catch (Exception e)
			{
				Console.WriteLine("FTP Server VFS Error during root check: " + e.ToString());
			}

			Console.WriteLine("FTP Server IP: " + address.ToString());
			this.controlListener = new TcpListener(address, controlPort);
			Start();
		}

		public void Start()
		{
			this.controlListener.Start();
			Console.WriteLine("FTP Control listening on port: " + controlPort);
			while (true)
			{
				try
				{
					TcpClient client = this.controlListener.AcceptTcpClient();
					Console.WriteLine("FTP Client connected from: " + client.Client.RemoteEndPoint);
					HandleClientControl(client);
				}
				catch (Exception ex)
				{
					Console.WriteLine("FTP Control Listener Error: " + ex.Message);
				}
			}
		}

		private TcpClient dataClient;

		private void HandleClientControl(TcpClient client)
		{
			NetworkStream stream = client.GetStream();
			StreamReader reader = new StreamReader(stream, Encoding.ASCII);
			StreamWriter writer = new StreamWriter(stream, Encoding.ASCII) { AutoFlush = true };

			writer.WriteLine("220 Cosmos FTP Server Ready.");

			string line;
			bool loggedIn = false;
			string currentDirectory = rootPath;
			try
			{
				while (client.Connected && (line = reader.ReadLine()) != null)
				{
					Console.WriteLine("FTP CMD: " + line);
					string[] parts = line.Split(' ', 2);
					string command = parts[0].ToUpper();
					string argument = parts.Length > 1 ? parts[1] : string.Empty;

					switch (command)
					{
						case "USER":
							writer.WriteLine("331 Password required for " + argument + ".");
							break;
						case "PASS":
							if (argument == FtpPassword)
							{
								loggedIn = true;
								writer.WriteLine("230 User logged in.");
							}
							else
							{
								writer.WriteLine("530 Not logged in.");
							}
							break;
						case "SYST":
							writer.WriteLine("215 UNIX Type: L8");
							break;
						case "FEAT":
							writer.WriteLine("211-Features:");
							writer.WriteLine(" SIZE");
							writer.WriteLine(" PASV");
							writer.WriteLine("211 End");
							break;
						case "CWD":
							if (!loggedIn) { writer.WriteLine("530 Not logged in."); break; }
							string requestedPath = Path.Combine(currentDirectory, argument).Replace('/', Path.DirectorySeparatorChar);
							if (!requestedPath.StartsWith(rootPath, StringComparison.OrdinalIgnoreCase))
							{
								writer.WriteLine("550 Access denied.");
								break;
							}

							try
							{
								if (Directory.Exists(requestedPath))
								{
									currentDirectory = requestedPath;
									writer.WriteLine("250 Directory successfully changed to " + currentDirectory.Replace(rootPath, "/").Replace(Path.DirectorySeparatorChar, '/') + ".");
								}
								else
								{
									writer.WriteLine("550 Directory not found.");
								}
							}
							catch (Exception ex)
							{
								writer.WriteLine("550 Directory change failed: " + ex.Message);
								Console.WriteLine("FTP CWD Error: " + ex.Message);
							}
							break;
						case "PWD":
						case "XPWD":
							if (!loggedIn) { writer.WriteLine("530 Not logged in."); break; }
							string displayPath = currentDirectory.Replace(rootPath, "");
							if (string.IsNullOrEmpty(displayPath)) displayPath = "/";
							displayPath = displayPath.Replace(Path.DirectorySeparatorChar, '/');
							writer.WriteLine("257 \"" + displayPath + "\" is current directory.");
							break;
						case "TYPE":
							writer.WriteLine("200 Type set to " + argument + ".");
							break;
						case "PASV":
							if (!loggedIn) { writer.WriteLine("530 Not logged in."); break; }
							dataClient = HandlePasvCommand(writer, client.Client.LocalEndPoint as IPEndPoint);
							break;
						case "LIST":
						case "NLST":
							if (!loggedIn) { writer.WriteLine("530 Not logged in."); break; }
							HandleListCommand(writer, dataClient, currentDirectory, command == "LIST");
							dataClient?.Close();
							dataClient = null;
							break;
						case "RETR":
							if (!loggedIn) { writer.WriteLine("530 Not logged in."); break; }
							HandleRetrCommand(writer, dataClient, currentDirectory, argument);
							dataClient?.Close();
							dataClient = null;
							break;
						case "QUIT":
							writer.WriteLine("221 Goodbye.");
							return;
						default:
							writer.WriteLine("500 Unknown command: " + command);
							break;
					}
				}
			}
			catch (IOException ex)
			{
				Console.WriteLine($"FTP Control Client disconnected or I/O error: {ex.Message}");
			}
			catch (Exception ex)
			{
				Console.WriteLine($"FTP Control Error: {ex.Message}");
				writer.WriteLine($"500 Server error: {ex.Message}");
			}
			finally
			{
				dataClient?.Close();
				client?.Close();
				Console.WriteLine("FTP Client disconnected.");
			}
		}

		private TcpClient HandlePasvCommand(StreamWriter writer, IPEndPoint localEndPoint)
		{
			TcpListener pasvListener = null;
			try
			{
				passivePortCounter++;
				if (passivePortCounter > 65535) passivePortCounter = 10000;

				int dataPort = passivePortCounter;
				pasvListener = new TcpListener(localEndPoint.Address, dataPort);
				pasvListener.Start();

				byte[] ipBytes = localEndPoint.Address.GetAddressBytes();
				byte p1 = (byte)(dataPort / 256);
				byte p2 = (byte)(dataPort % 256);

				writer.WriteLine($"227 Entering Passive Mode ({ipBytes[0]},{ipBytes[1]},{ipBytes[2]},{ipBytes[3]},{p1},{p2})");
				Console.WriteLine($"FTP Server: Waiting for data connection on port {dataPort}");

				TcpClient acceptedDataClient = pasvListener.AcceptTcpClient();
				Console.WriteLine("FTP Data Client connected.");
				return acceptedDataClient;
			}
			catch (Exception ex)
			{
				writer.WriteLine("425 Can't open data connection: " + ex.Message);
				Console.WriteLine("FTP PASV Error: " + ex.Message);
				return null;
			}
			finally
			{
				pasvListener?.Stop();
			}
		}

		private void HandleListCommand(StreamWriter controlWriter, TcpClient dataClient, string path, bool longFormat)
		{
			if (dataClient == null || !dataClient.Connected)
			{
				controlWriter.WriteLine("425 No data connection established.");
				return;
			}

			try
			{
				using (NetworkStream dataStream = dataClient.GetStream())
				using (StreamWriter dataWriter = new StreamWriter(dataStream, Encoding.ASCII) { AutoFlush = true })
				{
					controlWriter.WriteLine("150 Opening ASCII mode data connection for file list.");

					foreach (string dir in Directory.GetDirectories(path))
					{
						string dirname = Path.GetFileName(dir);
						if (longFormat)
						{
							dataWriter.WriteLine($"drwxr-xr-x 1 ftp ftp 0 Jan 01 1970 {dirname}");
						}
						else
						{
							dataWriter.WriteLine(dirname);
						}
					}

					foreach (string file in Directory.GetFiles(path))
					{
						string filename = Path.GetFileName(file);
						long fileSize = 0;

						try
						{
							using (var fs = File.OpenRead(file))
							{
								fileSize = fs.Length;
							}
						}
						catch (Exception ex)
						{
							Console.WriteLine($"FTP Server: Could not get file size for {file}: {ex.Message}");
						}

						if (longFormat)
						{
							dataWriter.WriteLine($"-rw-r--r-- 1 ftp ftp {fileSize} Jan 01 1970 {filename}");
						}
						else
						{
							dataWriter.WriteLine(filename);
						}
					}

					dataWriter.Flush();
					controlWriter.WriteLine("226 Transfer complete.");
				}
			}
			catch (Exception ex)
			{
				controlWriter.WriteLine("451 Requested action aborted. Local error in processing.");
				Console.WriteLine("FTP LIST Error: " + ex.Message);
			}
			finally
			{
				dataClient?.Close();
			}
		}

		private void HandleRetrCommand(StreamWriter controlWriter, TcpClient dataClient, string path, string filename)
		{
			if (dataClient == null || !dataClient.Connected)
			{
				controlWriter.WriteLine("425 No data connection established.");
				return;
			}

			string filePath = Path.Combine(path, filename);
			if (!File.Exists(filePath))
			{
				controlWriter.WriteLine("550 File not found.");
				dataClient.Close();
				return;
			}

			try
			{
				using (NetworkStream dataStream = dataClient.GetStream())
				{
					controlWriter.WriteLine("150 Opening BINARY mode data connection for " + filename);

					byte[] fileBytes = File.ReadAllBytes(filePath);
					dataStream.Write(fileBytes, 0, fileBytes.Length);
					dataStream.Flush();

					controlWriter.WriteLine("226 Transfer complete.");
				}
			}
			catch (Exception ex)
			{
				controlWriter.WriteLine("451 Requested action aborted. Local error in processing.");
				Console.WriteLine("FTP RETR Error: " + ex.Message);
			}
			finally
			{
				dataClient.Close();
			}
		}
	}
}